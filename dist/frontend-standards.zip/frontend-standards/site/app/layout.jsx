import './styles.css';
import '@fontsource/google-sans/400.css';
import '@fontsource/google-sans/500.css';
import '@fontsource/google-sans/600.css';
import '@fontsource/google-sans/700.css';

export const metadata = {
  title: 'Frontend Standards — The frontend playbook for coding agents',
  description: 'An opinionated Agent Skill for polished, consistent Next.js interfaces.',
};

export default function RootLayout({ children }) {
  return <html lang="he" dir="rtl"><body>{children}</body></html>;
}
