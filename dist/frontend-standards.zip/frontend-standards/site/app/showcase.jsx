"use client";

import { useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CursorClick,
  HandSwipeLeft,
  Stack,
  Swatches,
} from "@phosphor-icons/react";

const libraries = [
  {
    name: "Next.js",
    type: "Framework",
    short: "Server-first architecture",
    detail:
      "שומר על App או Pages Router הקיים. מעדיף Server Components ויכולות native כמו Image, Link, Metadata, Route Handlers, caching ו-revalidation.",
  },
  {
    name: "Base UI",
    type: "Primitives",
    short: "Accessible desktop UI",
    detail:
      "Dialog, Menu, Popover, Select, Combobox ו-Autocomplete נגישים בדסקטופ, לפני המצאת primitive חדש.",
  },
  {
    name: "Vaul",
    type: "Mobile",
    short: "Gesture-native drawers",
    detail:
      "כל dialog או picker קומפקטי הופך במובייל ל-bottom drawer עם drag-to-dismiss, focus תקין ואותו state.",
  },
  {
    name: "Motion",
    type: "Animation",
    short: "Physical, interruptible motion",
    detail:
      "Springs, swipe, drag, scrub, icon swaps ומעברים הפיכים. תנועה מתחילה מיד, עוקבת 1:1 ומכבדת reduced motion.",
  },
  {
    name: "Auto Animate",
    type: "Layout",
    short: "Dynamic drawer content",
    detail:
      "מנפיש הוספה, הסרה, reorder ושינויי גובה בתוך drawers ותוכן דינמי בלי לנהל transitions ידנית.",
  },
  {
    name: "Phosphor",
    type: "Icons",
    short: "One coherent icon family",
    detail:
      "Regular במצב לא פעיל, Fill במצב selected או active, עם החלפת icon דרך opacity, blur ו-scale.",
  },
  {
    name: "Google Sans",
    type: "Typography",
    short: "One type system",
    detail:
      "Google Sans בכל הממשק, כולל עברית. בלי monospace ובלי letter-spacing מותאם אישית.",
  },
  {
    name: "TanStack Query",
    type: "Server state",
    short: "Optimistic by default",
    detail:
      "Caching, polling ו-mutations עם cancel, snapshot, prediction, rollback ו-reconciliation. לא fetch בתוך useEffect.",
  },
  {
    name: "Boneyard",
    type: "Loading",
    short: "Skeletons from real DOM",
    detail:
      "Skeleton שמופק מהקומפוננטה האמיתית ושומר על hierarchy, spacing, radius ו-breakpoints בלי layout shift.",
  },
  {
    name: "NumberFlow",
    type: "Numbers",
    short: "Animated numeric changes",
    detail:
      "שינויים במספרים מקבלים transition רציף וקריא, עם בידוד LTR נכון גם בתוך ממשק עברי.",
  },
  {
    name: "Sonner",
    type: "Feedback",
    short: "Clear, lightweight toasts",
    detail:
      "Toast אחיד לפידבק שאינו חוסם את המשימה, בלי לבנות מערכת notifications חדשה.",
  },
  {
    name: "Zustand",
    type: "Client state",
    short: "Only when state is truly shared",
    detail:
      "נכנס רק אחרי ש-local state, URL state, context ו-server state נפסלו כבעלים נכונים.",
  },
  {
    name: "Virtuoso",
    type: "Performance",
    short: "Long-list virtualization",
    detail:
      "רשימות גדולות נשארות חלקות ונגישות באמצעות virtualization ייעודי במקום פתרון ידני.",
  },
  {
    name: "dnd-kit",
    type: "Drag & drop",
    short: "Sortable, accessible drag",
    detail:
      "Reorder ו-drag-and-drop עם pointer, touch ו-keyboard. גרירה לעולם אינה הדרך היחידה לבצע פעולה.",
  },
  {
    name: "Recharts",
    type: "Charts",
    short: "General data visualization",
    detail:
      "ברירת המחדל לגרפים ודשבורדים רגילים, עם responsive layout ו-semantics שמתאימים למוצר.",
  },
  {
    name: "Liveline",
    type: "Streaming charts",
    short: "Live time-series data",
    detail:
      "הבחירה לגרפי time-series זורמים, כש-Recharts אינו מיועד לקצב העדכונים הנדרש.",
  },
];

const capabilities = [
  {
    icon: Stack,
    title: "Architecture",
    lead: "מבין לפני שהוא משנה.",
    items: [
      "Inspect מלא לריפו",
      "שומר על ה-router הקיים",
      "Server Components כברירת מחדל",
      "Client boundary מינימלי",
      "ללא dependency churn",
    ],
  },
  {
    icon: HandSwipeLeft,
    title: "Interaction",
    lead: "מרגיש נכון בכל input.",
    items: [
      "Dialog בדסקטופ, Drawer במובייל",
      "Drag, swipe, momentum ו-springs",
      "Animated icon transitions",
      "Sticky bottom actions",
      "חלופת click ו-keyboard לכל gesture",
    ],
  },
  {
    icon: CursorClick,
    title: "State & loading",
    lead: "מגיב מיד, בלי לקפוץ.",
    items: [
      "Optimistic mutations + rollback",
      "הגנה על concurrent mutations",
      "Boneyard skeletons",
      "תוכן נשאר בזמן refetch",
      "NumberFlow ו-Sonner לפידבק",
    ],
  },
  {
    icon: Swatches,
    title: "Quality",
    lead: "לא נגמר ב״נראה טוב״.",
    items: [
      "Accessibility ו-focus",
      "עברית ו-RTL",
      "Reduced motion ו-transparency",
      "Latest stable בלבד",
      "Format, typecheck, lint, tests ו-build",
    ],
  },
];

export default function Showcase() {
  const [selected, setSelected] = useState(0);
  const scroller = useRef(null);
  const reduceMotion = useReducedMotion();
  const scroll = (direction) =>
    scroller.current?.scrollBy({
      left: direction * 330,
      behavior: reduceMotion ? "auto" : "smooth",
    });

  return (
    <>
      <div className="carouselControls">
        <div className="counter" dir="ltr">
          <b>{String(selected + 1).padStart(2, "0")}</b>
          <span>/ {libraries.length}</span>
        </div>
        <div className="arrows" dir="ltr">
          <button onClick={() => scroll(-1)} aria-label="Previous library">
            <ArrowLeft weight="bold" />
          </button>
          <button onClick={() => scroll(1)} aria-label="Next library">
            <ArrowRight weight="bold" />
          </button>
        </div>
      </div>
      <div className="carousel" ref={scroller} dir="ltr">
        {libraries.map((library, index) => (
          <motion.button
            key={library.name}
            className={`libraryCard ${selected === index ? "active" : ""}`}
            onClick={() => setSelected(index)}
            whileTap={reduceMotion ? undefined : { scale: 0.97 }}
            aria-pressed={selected === index}
          >
            <small>{library.type}</small>
            <strong>{library.name}</strong>
            <span>{library.short}</span>
            <i>{String(index + 1).padStart(2, "0")}</i>
          </motion.button>
        ))}
      </div>
      <div className="libraryDetail" aria-live="polite">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={libraries[selected].name}
            initial={
              reduceMotion
                ? { opacity: 0 }
                : { opacity: 0, filter: "blur(8px)", y: 12 }
            }
            animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
            exit={
              reduceMotion
                ? { opacity: 0 }
                : { opacity: 0, filter: "blur(8px)", y: -8 }
            }
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
          >
            <span>{libraries[selected].type}</span>
            <h3 dir="ltr">{libraries[selected].name}</h3>
            <p>{libraries[selected].detail}</p>
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="capabilityHeader">
        <span>החוקים שהסקיל אוכף</span>
        <h2>
          לא רק במה להשתמש.
          <br />
          גם איך ליישם נכון.
        </h2>
      </div>
      <div className="capabilityGrid">
        {capabilities.map(({ icon: Icon, title, lead, items }, index) => (
          <motion.article
            key={title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ delay: reduceMotion ? 0 : index * 0.06 }}
          >
            <div className="capIcon">
              <Icon size={26} weight="regular" />
            </div>
            <small>{title}</small>
            <h3>{lead}</h3>
            <ul>
              {items.map((item) => (
                <li key={item}>
                  <Check weight="bold" />
                  {item}
                </li>
              ))}
            </ul>
          </motion.article>
        ))}
      </div>
    </>
  );
}
